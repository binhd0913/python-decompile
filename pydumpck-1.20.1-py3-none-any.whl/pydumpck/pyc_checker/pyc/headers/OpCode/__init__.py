class OpCodeBase:
    code = {}
